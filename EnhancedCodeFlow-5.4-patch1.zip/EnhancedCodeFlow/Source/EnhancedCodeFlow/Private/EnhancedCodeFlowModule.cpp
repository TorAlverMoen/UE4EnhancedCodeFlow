// Copyright (c) 2024 Damian Nowakowski. All rights reserved.

#include "Modules/ModuleManager.h"

class ENHANCEDCODEFLOW_API FEnhancedCodeFlowModule : public IModuleInterface
{};

IMPLEMENT_MODULE(FEnhancedCodeFlowModule, EnhancedCodeFlow)
